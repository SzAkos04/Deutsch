---
Thema: Partizipien
Kategorie: Adjektive
Niveau: B1
Quelle: Cosmopolitan Lingua
Schwäche: false
tags: [Grammatik]
---
# `=this.Thema`
**Kategorie:** `=this.Kategorie` | **Niveau:** `=this.Niveau` | **Quelle:** `=this.Quelle`

## Elmélet

### I. Folyamatos / jelen idejű melléknévi igenév

**a) Módhatározóként**
Infinitiv + d – magyarban va, -ve, -ván, -vén
*Mein Freund schläft immer stehend.* – A barátom mindig állva alszik.

**b) Jelzőként**
Infinitiv + d + melléknév végződés – magyarban ó, -ő
*Siehst du die lachende Frau?* – Látod a nevető nőt?

### II. Befejezett / múlt idejű melléknévi igenév

**a) Módhatározóként**
sein + Partizip Perfekt
*Die Tür ist geschlossen.* – Az ajtó be van zárva.

**b) Jelzőként**
Partizip Perfekt + melléknév végződés
*Der geschriebene Brief liegt hier.* – A megírt levél itt fekszik.

### III. Beálló / jövő idejű melléknévi igenév

Lehetőség/szükségszerűség – andó, -endő, ható, -hető
**zu + Infinitiv + d + melléknév végződés**
*der zu reparierende Kühlschrank* – a megjavítandó hűtő

## Feladatok

> [!question]- Feladat 1 (folyamatos melléknévi igenév) – Forditsd le a mondatokat!
> 1. A barátnőm sétálva olvas.
> 2. A köhögő férfi itt lakik.
> 3. Józsi énekelve cigarettázik.
> 4. Játszva dolgozik.
> 5. Az olvasó nőnek 3 gyereke van.
> 6. A nevető lány tetszik nekem.

%%.%%
> [!success]- Megoldás
> *(A forrásanyagban nem szerepelt megoldókulcs.)*

%%.%%

> [!question]- Feladat 2 (befejezett melléknévi igenév) – Fordítsd le a mondatokat!
> 1. Az asztal meg van terítve.
> 2. Az ellopott kerékpár az enyém.
> 3. Az elolvasott könyv ott van.
> 4. A poharak el vannak mosogatva.
> 5. Az elhozott vendégek a buszon vannak.
> 6. A kép ki van állítva.

%%.%%
> [!success]- Megoldás
> *(A forrásanyagban nem szerepelt megoldókulcs.)*

%%.%%

> [!question]- Feladat 3 (beálló melléknévi igenév) – Fordítsd le!
> 1. egy megjavítandó rádió
> 2. a megtanulandó szavak
> 3. egy elolvasandó könyv
> 4. a megoldandó feladatok
> 5. egy megírandó levél

%%.%%
> [!success]- Megoldás
> *(A forrásanyagban nem szerepelt megoldókulcs.)*

%%.%%

> [!question]- Feladat 4 – Fordítsd le mindhárom melléknévi igenevet használva!
> 1. az elolvasott könyv
> 2. az író gyerek
> 3. egy feladandó hirdetés
> 4. egy képzett orvostól
> 5. a kicsomagolt ajándékban
> 6. az ülő lány fölött
> 7. egy kitakarított iroda
> 8. az értesítendő rendőrség
> 9. a kitöltendő nyomtatványon
> 10. egy berendezett szoba
> 11. az elénekelt dal szövege
> 12. egy várakozó utas mellett
> 13. egy megterített asztalon
> 14. a kiadó szoba
> 15. egy felépült ház sarkán
> 16. egy síró gyerek
> 17. a dolgozó asszony
> 18. egy éneklő csapat
> 19. a futó sportolóról
> 20. a virágzó növény
> 21. a megtalált kincsekből
> 22. egy állólámpa alatt
> 23. egy alvó kutya mögött
> 24. a megrendelt áruk listája
> 25. a megöntözött növények
> 26. zárt ajtók
> 27. a növekvő munkanélküliség

%%.%%
> [!success]- Megoldás
> 1. das gelesene Buch
> 2. das schreibende Kind
> 3. ein aufzugebende Anzeige
> 4. von einem gebildeten Arzt
> 5. im ausgepackten Geschenk
> 6. über dem sitzenden Mädchen
> 7. ein aufgeräumtes Büro
> 8. die zu benachrichtigende Polizei
> 9. auf dem auszufüllenden Formular
> 10. ein möbliertes Zimmer
> 11. der Text des gesungenen Liedes
> 12. neben einem wartenden Fahrgast
> 13. auf einem aufgedeckten Tisch
> 14. das vermietende Zimmer
> 15. an der Ecke eines gebauten Hauses
> 16. ein weinendes Kind
> 17. die arbeitende Frau
> 18. ein singendes Team
> 19. von dem laufenden Sportler
> 20. die blühende Pflanze
> 21. aus den gefundenen Schätzen
> 22. unter einer stehenden Lampe
> 23. hinter einem schlafenden Hund
> 24. die Liste der bestellten Produkte
> 25. die gegossenen Pflanzen
> 26. geschlossene Türen
> 27. die steigende Arbeitslosigkeit

%%.%%

---
## Siehe auch
- [[Adjektivdeklination]]
- [[Zu + Infinitiv (Grundlagen)]]
- [[Grammatik MOC]]
