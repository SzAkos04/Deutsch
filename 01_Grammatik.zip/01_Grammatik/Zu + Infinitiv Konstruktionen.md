---
Thema: Zu + Infinitiv Konstruktionen
Kategorie: Infinitivkonstruktionen
Niveau: B1
Quelle: Cosmopolitan Lingua
Schwäche: false
tags: [Grammatik]
---
# `=this.Thema`
**Kategorie:** `=this.Kategorie` | **Niveau:** `=this.Niveau` | **Quelle:** `=this.Quelle`

## Elmélet

### I. scheinen zu + Infinitiv – úgy tűnik, hogy
**a) Jelen idő:** *Der Professor scheint dafür keine Lösung zu finden.* – Úgy tűnik, hogy a professzor nem talál rá megoldást.
**b) Múlt idő:** *Mein Vater scheint gestern viel gearbeitet zu haben.* – Úgy tűnik, apám tegnap sokat dolgozott.

### II. brauchen zu + Infinitiv – (nem) kell
Többnyire tagadó mondatokban alkalmazzuk, jelentése „enyhébb" mint a *müssen*-é vagy a *sollen*-é.
*Davor brauchst du keine Angst zu haben.* – Nem kell neked attól félned.

### III. haben zu + Infinitiv – szükségességet fejez ki (kell, sollen/müssen helyett)
A *haben zu + Infinitiv*-nél ismerem a cselekvés végrehajtóját (aktív).
*Er muss mein Auto noch heute reparieren.* = *Er hat mein Auto noch heute zu reparieren.*

### IV. sein zu + Infinitiv – kell, lehet (passzív jellegű szerkezet)
A *haben zu + Infinitiv*-vel ellentétben itt nem ismerem a cselekvés végrehajtóját. Ez is egyfajta passzív szerkezet, tehát amit a magyarban tárgyesetben fordítunk, az ennek a mondatnak az alanya.
*Das Auto ist nicht mehr zu reparieren.* – Az autót már nem lehet megjavítani.
*Diese Angelegenheit ist noch heute zu erledigen.* – Ezt az ügyet még ma el kell intézni.

### V. ohne dass és ohne zu + Infinitiv
Anélkül, hogy…
- **ohne zu** – azonos alanyoknál
- **ohne dass** + KATI – különböző alanyoknál, vagy azonos alanyoknál

*Er geht von zu Hause weg, ohne nachher die Tür zu schließen.* – Elmegy otthonról anélkül, hogy utána becsukná az ajtót.
*Er fährt das Auto von Peter, ohne dass es ihm Peter erlaubt.* – Péter kocsijával jár anélkül, hogy Péter megengedné.

> [!tip] Múlt idő
> Ha az „ohne" mondatrész után múlt idő áll, akkor azt a mondatrészt Perfektbe kell tenni, az első mondatrész pedig Präteritumban van.
> *Ich stieg aus der Badewanne, ohne meinen linken Fuß gewaschen zu haben.* – Kiszálltam a kádból anélkül, hogy megmostam volna a bal lábamat.

### VI. anstatt dass és anstatt zu + Infinitiv
Ahelyett, hogy
- **anstatt zu** – azonos alanyoknál
- **anstatt dass** + KATI – különböző alanyoknál, vagy azonos alanyoknál

*Er liegt den ganzen Tag in der Sonne, anstatt mir zu helfen.* – Egész nap napozik ahelyett, hogy segítene nekem.
*Oma hilft ihren Enkelkindern, anstatt dass sie Oma pflegen* – Nagyi segit az unokáinak ahelyett, hogy ők ápolnák nagyit.

### VII. Célhatározói mellékmondat – um zu + Infinitiv és damit + KATI szórend
(azért), hogy / a célból, hogy
- **um zu + Infinitiv** – azonos alany
- **damit + KATI** – különböző alany / azonos alany

*Ich gehe zur Oma, um ihr beim Abwasch zu helfen.* – Elmegyek a nagyihoz azért, hogy segítsek neki a mosogatásban.
*Ich gehe zur Oma, damit sie mir etwas kocht.* – Elmegyek a nagyihoz, hogy főzzön nekem valamit.

> [!tip] Módbeli segédigékkel
> *Ich gebe dir eine Tablette, damit du besser schlafen kannst.* – Adok neked egy tablettát, hogy jobban tudj aludni.
> *Ich nehme eine Tablette ein, um besser schlafen zu können.* – Beveszek egy tablettát, hogy jobban tudjak aludni.

## Feladatok

> [!question]- Feladat 1 (scheinen zu) – Fordítsd le a mondatokat!
> 1. Úgy tűnik, hogy ma se jön a barátod.
> 2. Úgy tűnt, hogy Klári nem érzi jól magát.
> 3. Úgy tűnik, hogy hétfőn nem voltak otthon.
> 4. Úgy tűnik, hogy tegnap mindent megettek.
> 5. A barátod fáradtnak tűnik.
> 6. Úgy tűnik, túl sokat ivott.
> 7. Úgy tűnik, hogy már felépítették a házat.
> 8. Úgy tűnik, hogy eltörted a lábad.
> 9. Úgy tűnik, nem fél a kígyótól.
> 10. Úgy tűnik, sokat eszik a barátod.
> 11. Úgy tűnik tegnap megint hazudott.
> 12. Úgy tűnik nem adták el a kocsijukat.
> 13. Úgy tűnik, még nem javította meg az órámat.
> 14. A feleséged szomorúnak tűnik.
> 15. Ez a hal frissnek tűnik.
> 16. Úgy tűnik, hogy tegnap mindent megettek.

%%.%%
> [!success]- Megoldás
> 1. Dein Freund scheint heute nicht zu kommen.
> 2. Klari scheint nicht so gut angefühlt zu haben.
> 3. Sie scheinen am Montag nicht zu Hause gewesen zu sein.
> 4. Sie scheint gestern alles gegessen zu haben.
> 5. Dein Freund scheint müde zu sein.
> 6. Er scheint zu viel getrunken zu haben.
> 7. Das Haus scheint schon gebaut worden zu sein.
> 8. Du scheinst dich dein Bein gebrochen zu haben.
> 9. Er scheint vor Schlagen keine Angst zu haben.
> 10. Dein Freund scheint viel zu essen.
> 11. Er scheint gestern wieder gelogen zu haben.
> 12. Sie scheinen sein Auto nicht verkauft zu haben.
>     Ihr Auto scheint nicht verkauft worden zu sein.
> 13. Er scheint meine Uhr noch nicht repariert zu haben.
> 14. Deine Frau scheint traurig zu sein.
> 15. Dieser Fisch scheint frisch zu sein.
> 16. Sie scheinen gestern alles gegessen zu haben.

%%.%%

> [!question]- Feladat 2 (brauchen zu) – Fordítsd le a mondatokat!
> 1. Nem kell emiatt idegeskedned!
> 2. Nem kell ezt úgy a szívedre venned!
> 3. Vasárnap nem kell olyan korán felkelnetek.
> 4. Nem kell olyan melegen felöltözködnötök.
> 5. Azt nem kell neki kétszer mondanod…
> 6. Valószínűleg nem kell mondanom, hogy ti is meg vagytok hívva.
> 7. Ezért nem kell mindjárt sírnod.
> 8. Ezt nem kell megjegyezned, ez nem olyan fontos.
> 9. Valószínűleg nem kell mondanom, hogy nem kell jönnötök nyáron iskolába.
> 10. Ma mindent bevásárolok, így a feleségemnek holnap semmit se kell beszereznie.

%%.%%
> [!success]- Megoldás
> 1. Du brauchst dich darüber nicht zu ärgern.
> 2. Du brauchst dir das nicht zu Herzen zu nehmen.
> 3. Am Sonntag braucht ihr nicht so früh aufzustehen.
> 4. Ihr braucht euch nicht so warm anzuziehen.
> 5. Das brauchst du ihm nicht zweimal zu sagen...
> 6. Wahrscheinlich brauche ich euch nicht zweimal zu sagen, dass ihr auch eingeladen seid.
> 7. Deshalb brauchst du nicht gleich zu weinen.
> 8. Das brauchst du dir nicht zu merken, das ist nicht so wichtig.
> 9. Wahrscheinlich brauche ich euch nicht zu sagen, dass ihr im Sommer nicht zur Schule kommen müsst.
> 10. Heute kaufe ich alles ein, deshalb braucht meine Frau morgen nichts zu besorgen.

%%.%%

> [!question]- Feladat 3 (haben zu) – Fordítsd le a mondatokat!
> 1. Még ma meg kell csinálnod a házidat.
> 2. Írnunk kell egy levelezőlapot.
> 3. A mérnöknek meg kell terveznie a házat.
> 4. Anyát fel kell hívnod 2-kor.
> 5. Ki kell takarítanod a szobát.
> 6. Be kell fizetnem a pénzt.
> 7. A péknek friss kenyeret kell sütnie.
> 8. Az orvosnak meg kell gyógyítania a beteget.
> 9. Be kell pakolnunk a bőröndbe.
> 10. Két levelet kell írnom.
> 11. Fel kell húznom az órát.
> 12. Fel kell adnia a csomagot.

%%.%%
> [!success]- Megoldás
> 1. Du hast noch heute deine Hausaufgabe zu machen.
> 2. Wir haben eine Postkarte schreiben.
> 3. Der Ingenieur hat das Haus zu entwerfen.
> 4. Du hast Mutti um 2 Uhr anzurufen.
> 5. Du hast dein Zimmer aufzuräumen.
> 6. Ich habe das Geld zu bezahlen.
> 7. Der Bäcker hat frisches Brot zu backen.
> 8. Der Arzt hat den Patient zu heilen.
> 9. Wir haben den Koffer zu packen.
> 10. Ich habe zwei Briefe zu schreiben.
> 11. Ich habe die Uhr aufzuziehen.
> 12. Er hat das Paket aufzugeben.

%%.%%

> [!question]- Feladat 4 (sein zu) – Fejezz ki lehetőséget és szükségszerűséget a sein zu + Infinitivvel.
> 1. Ezt a levelet még ma meg kell írni.
> 2. Ez alig hihető.
> 3. Ez a szabály könnyen megtanulható.
> 4. Ezt a virágot gyakran kell locsolni.
> 5. Ezt a könyvet egyszerűen nem lehet elolvasni.
> 6. Ez a vers lefordíthatatlan.
> 7. A magatartása nem magyarázható.
> 8. Az almát alaposan meg kell mosni.
> 9. A munkát még ezen a héten be kell fejezni.
> 10. Az írásod alig olvasható.

%%.%%
> [!success]- Megoldás
> 1. Dieser Brief ist noch heute zu schreiben.
> 2. Das ist kaum zu glauben.
> 3. Diese Regel ist leicht zu lernen.
> 4. Diese Blume oft zu gießen.
> 5. Dieses Buch ist einfach nicht zu lesen.
> 6. Dieses Gedicht ist nicht zu übersetzen.
> 7. Sein Verhalten ist nicht zu erklären.
> 8. Der Apfel ist gründlich zu waschen.
> 9. Die Arbeit ist noch diese Woche zu beenden.
> 10. Dein Schrift ist kaum zu lesen.

%%.%%

> [!question]- Feladat 5 – Haben vagy sein zu + Infinitiv?
> 1. A szőlőt alaposan meg kell mosni.
> 2. A szőlőt alaposan meg kell mosnom.
> 3. Ki kell nyitnom az ablakot.
> 4. Az ablakot ki kell nyitni.
> 5. Meg kell szerelnem a kocsit.
> 6. A kocsit meg kell szerelni.
> 7. Fel kell adnom a levelet.
> 8. A levelet fel kell adni.

%%.%%
> [!success]- Megoldás
> 1. Die Traube ist gründlich zu waschen.
> 2. Ich habe die Traube gründlich zu waschen.
> 3. Ich habe das Fenster zu öffnen.
> 4. Das Fenster ist zu öffnen.
> 5. Ich habe das Auto zu reparieren.
> 6. Das Auto ist zu reparieren.
> 7. Ich habe den Brief aufzugeben.
> 8. Der Brief ist aufzugeben.

%%.%%

> [!question]- Feladat 6 (ohne dass / ohne zu) – Fordítsd le a mondatokat ohne dass-t, vagy ohne zu + Infinitiv-et használva.
> 1. Belép a szobámba anélkül, hogy kopogna.
> 2. Könyveket olvas, anélkül, hogy megértené őket.
> 3. Adok neki egy puszit anélkül, hogy megengedné.
> 4. Elmegyek a házuk előtt anélkül, hogy észrevenne.
> 5. Eljönnek hozzám anélkül, hogy megengedném nekik.
> 6. Mindig pontosan érkezem anélkül, hogy lenne karórám.
> 7. Megnézi a képeimet anélkül, hogy közben mondana valamit.
> 8. Az irodába megy anélkül, hogy elköszönne tőlem.

%%.%%
> [!success]- Megoldás
> 1. Er betritt mein Zimmer, ohne zu klopfen.
> 2. Er liest Bücher, ohne sie zu verstehen.
> 3. Ich gebe ihr einen Kuss, ohne dass sie es erlaubt.
> 4. Ich gehe an ihrem Haus vorbei, ohne dass er mich bemerkt.
> 5. Sie kommt zu mir, ohne dass ich ihnen erlaube.
> 6. Ich komme immer pünktlich an, ohne dass ich eine Armbanduhr habe.
> 7. Er schaut meine Bilder an, ohne etwas zu sagen.
> 8. Er geht ins Büro, ohne sich von mir zu verabschieden.

%%.%%

> [!question]- Feladat 7 (múlt idő, Infinitiv Perfekt) – Fejezz ki előidejűséget Infinitiv Perfekttel!
> 1. Béla megint kapott egy ötöst anélkül, hogy tanult volna.
> 2. A kollégám fizetésemelést kap anélkül, hogy részt vett volna a munkában.
> 3. Tudott venni egy új házat anélkül, hogy a régit eladta volna.
> 4. Visszavitt néhány könyvet a könyvtárba anélkül, hogy elolvasta volna.
> 5. Felvettem az ingemet anélkül, hogy a feleségem kivasalta volna.
> 6. A barátom letette a nyelvvizsgát anélkül, hogy tanult volna.

%%.%%
> [!success]- Megoldás
> 1. Bela bekam wieder eine Fünf, ohne gelernt zu haben.
> 2. Mein Kollege bekam eine Gehaltsaufbesserung, ohne an der Arbeit teilgenommen zu haben.
> 3. Er konnte ein neues Haus kaufen, ohne das alte verkauft zu haben.
> 4. Er brachte ein paar Bücher in die Bibliothek zurück, ohne sie gelesen zu haben.
> 5. Ich zog mein Hemd an, ohne dass meine Frau ausgebügelt hatte.
> 6. Mein Freund legte die Sprachprüfung ab, ohne gelernt zu haben.

%%.%%

> [!question]- Feladat 8 (anstatt dass / anstatt zu) – Fordítsd le a mondatokat anstatt dass-t, vagy anstatt zu + Infinitiv-et használva.
> 1. Az anyósom mindig idegesít ahelyett, hogy segítene.
> 2. Hosszú leveleket ír neki ahelyett, hogy felhívná őt.
> 3. Mi repülünk hozzájuk Kanadába ahelyett, hogy ők jönnének ide.
> 4. A munkanélküli segélyre vár ahelyett, hogy munkát keresne.
> 5. Moziba megy Gizivel ahelyett, hogy velem eljönne a színházba.

%%.%%
> [!success]- Megoldás
> 1. Meine Schwiegermutter ärgert mich immer, anstatt zu helfen.
> 2. Er hat ihm lange Briefe geschrieben, anstatt ihm angerufen.
> 3. Wir fliegen zu ihnen nach Kanada, anstatt dass sie hierher kommen.
> 4. Sie wartet auf Arbeitslosengeld, anstatt Job zu suchen.
> 5. Er geht mit Gizi ins Kino, anstatt mit mir ins Theater zu gehen.

%%.%%

> [!question]- Feladat 9 (um zu / damit) – Fordítsd le a mondatokat az um zu + Infinitiv és damit + KATI szórendes szerkezeteket használva!
> 1. Németországba utazok, hogy gyakoroljam a nyelvet.
> 2. Gyorsan futunk, hogy elérjük a villamost.
> 3. Segítünk a nagyinak, hogy egészséges maradjon.
> 4. Az orvos megoperálja a macskámat, hogy sokáig éljen.
> 5. Odaadom a fésűmet, hogy fésülködj meg.
> 6. Adott nekem egy pofont, hogy jól érezzem magam.
> 7. Eljött hozzám, hogy segítsen nekem.
> 8. Elmosogatok, hogy anya örüljön.
> 9. Felhúzom az órát, hogy nehogy elkéss.
> 10. Odaadja a telefonszámát, hogy holnap felhívjam.

%%.%%
> [!success]- Megoldás
> 1. Ich fahre nach Deutschland, um die Sprache zu üben.
> 2. Wir laufen schnell, um die Straßenbahn zu erreichen.
> 3. Wir helfen Oma, damit sie gesund bleibt.
> 4. Der Arzt operiert meine Katze, damit sie lange lebt.
> 5. Ich gebe dich meinen Kamm, damit du dich kämmst.
> 6. Er hat mir eine Ohrfeige gegeben, damit ich mir gut fühlte.
> 7. Er ist zu mir gekommen, um mich zu helfen.
> 8. Ich spüle ab, damit sich Mutti freut.
> 9. Ich stelle den Wecker, damit du dich nicht verspätest.
> 10. Er gibt mir seine Telefonnummer, damit ich ihn morgen anrufe.

%%.%%

> [!question]- Feladat 10 – um…zu vagy damit
> 1. Ich habe die Anzeigen in der Zeitung studiert. Ich wollte eine schöne Wohnung finden.
> 2. Ich bin in die Stadt gefahren. Ich wollte eine Adresse erfragen.
> 3. Ich beeilte mich. Niemand sollte mir zuvorkommen.
> 4. Wir haben die Wohnung genau vermessen. Die Möbel sollen später auch hineinpassen.
> 5. Ich habe viele kleine Sachen mit dem eigenen Wagen transportiert. Ich wollte Umzugskosten sparen.

%%.%%
> [!success]- Megoldás
> 1. Ich habe die Anzeigen in der Zeitung studiert, um eine schöne Wohnung zu finden.
> 2. Ich bin in die Stadt gefahren, um eine Adresse zu erfragen.
> 3. Ich beeilte mich, damit mir niemand zuvorkommen.
> 4. Wir haben die Wohnung genau vermessen, damit die Möbel später auch hineinpassen.
> 5. Ich habe viele kleine Sachen mit dem eigenen Wagen transportiert, um Umzugskosten zu sparen.

%%.%%

> [!question]- Feladat 11 (módbeli segédigével) – Fordítsd le a mondatokat!
> 1. A testvérem segít nekem, hogy meg tudjam írni a házit.
> 2. Sokat alszik, hogy holnap jól tudjon vezetni.
> 3. Hogy gyorsabban tudjon futni, mindig keveset eszik.
> 4. Becsukom az ajtót, hogy ne tudjon kimenni a kutya.
> 5. Megjavítom a kocsiját, hogy meg tudja nyerni a versenyt.
> 6. Inkább taxival megyek a repülőtérre, hogy el tudjam érni a repülőt.

%%.%%
> [!success]- Megoldás
> 1. Meine Schwester hilft mir, damit ich meine Hausaufgabe schreiben kann.
> 2. Er schläft viel, um morgen gut fahren zu können.
> 3. Er isst immer weniger, um schneller laufen zu können.
> 4. Ich schließe die Tür, damit der Hund nicht rausgehen kann.
> 5. Ich repariere seinen Wagen, damit er das Rennen gewinnen kann.
> 6. Ich fahre lieber mit dem Taxi zum Flughafen, um das Flugzeug zu erwischen.

%%.%%

> [!question]- Feladat 12 – um…zu, ohne…zu, anstatt…zu
> 1. Drei Bankräuber überfielen eine Bank. Sie wollten schnell reich werden.
> 2. Sie zählten das Geld nicht. Sie packten es in zwei Aktentaschen.
> 3. Die Bankräuber wechselten zweimal das Auto. Sie wollten schnell unerkannt verschwinden.
> 4. Sie nahmen nicht die beiden Taschen mit. Sie ließen eine Tasche im ersten Wagen liegen.
> 5. Sie kamen nicht noch einmal zurück. Die vergesslichen Gangster rasten mit dem zweiten Auto davon.
> 6. Sie fuhren zum Flughafen. Sie wollten nach Amerika entkommen.
> 7. Sie zahlten nicht mit einem Scheck. Sie kauften die Flugtickets mit dem gestohlenen Geld.
> 8. Sie wollten in der Großstadt untertauchen. Sie verließen in Buenos Aires das Flugzeug, wurden aber sofort verhaftet.
> 9. Sie ließen sich festnehmen. Sie leisteten keinen Widerstand.
> 10. Sie wurden nach Deutschland zurückgeflogen. Sie sollten vor Gericht gestellt werden.

%%.%%
> [!success]- Megoldás
> *(A forrásanyagban nem szerepelt megoldókulcs.)*

%%.%%

---
## Siehe auch
- [[Zu + Infinitiv (Grundlagen)]]
- [[Vorgangspassiv]]
- [[Grammatik MOC]]
